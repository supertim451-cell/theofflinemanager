const STORAGE_KEY = 'om_pw_vault_v1';

// Storage functions
function loadVault() {
  return new Promise((resolve) => {
    chrome.storage.local.get([STORAGE_KEY], (result) => {
      resolve(result[STORAGE_KEY] || {});
    });
  });
}

function saveVault(vault) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [STORAGE_KEY]: vault }, resolve);
  });
}

// Utility functions
function escapeHtml(s) {
  return s ? String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;') : '';
}

function escapeJs(s) {
  return s ? String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/\n/g,'\\n') : '';
}

// Add entry function
async function addEntry() {
  const name = document.getElementById('name').value.trim();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const notes = document.getElementById('notes').value.trim();
  
  if (!name) {
    alert('Site name is required');
    return;
  }
  
  const vault = await loadVault();
  const id = Date.now().toString(36);
  vault[id] = {
    name,
    username,
    password,
    notes,
    created: new Date().toISOString()
  };
  
  await saveVault(vault);
  renderList();
  
  // Clear form
  document.getElementById('name').value = '';
  document.getElementById('username').value = '';
  document.getElementById('password').value = '';
  document.getElementById('notes').value = '';
}

// Delete entry function
async function delEntry(id) {
  if (!confirm('Delete this entry?')) return;
  
  const vault = await loadVault();
  delete vault[id];
  await saveVault(vault);
  renderList();
}

// Copy text function
function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    // Show brief feedback
    const button = event.target;
    const originalText = button.textContent;
    button.textContent = 'Copied!';
    setTimeout(() => {
      button.textContent = originalText;
    }, 1000);
  }).catch(() => {
    alert('Copy failed');
  });
}

// Copy text function with button reference
function copyTextWithButton(text, button) {
  navigator.clipboard.writeText(text).then(() => {
    // Show brief feedback
    const originalText = button.textContent;
    button.textContent = 'Copied!';
    setTimeout(() => {
      button.textContent = originalText;
    }, 1000);
  }).catch(() => {
    alert('Copy failed');
  });
}

// Render list function
async function renderList() {
  const container = document.getElementById('list');
  container.innerHTML = '';
  
  const vault = await loadVault();
  const entries = Object.keys(vault).map(k => ({ id: k, item: vault[k] }));
  
  // Sort newest first
  entries.sort((a, b) => {
    const ta = a.item && a.item.created ? new Date(a.item.created).getTime() : 0;
    const tb = b.item && b.item.created ? new Date(b.item.created).getTime() : 0;
    return tb - ta;
  });
  
  if (entries.length === 0) {
    container.innerHTML = '<div class="small">No entries yet.</div>';
    return;
  }
  
  entries.forEach(({ id, item }) => {
    const row = document.createElement('div');
    row.className = 'entry credential-item';
    
    const name = escapeHtml(item.name || '');
    const username = escapeHtml(item.username || '');
    const notes = escapeHtml(item.notes || '');
    
    row.innerHTML = `
      <div class="entry-info">
        <div class="entry-name">${name}</div>
        <div class="entry-meta">${username}${notes ? ' • ' + notes : ''}</div>
      </div>
      <div class="entry-actions">        <button class="btn btn-small fill-btn" data-username="${escapeJs(item.username)}" data-password="${escapeJs(item.password)}">Fill</button>
        <button class="btn btn-small copy-btn" data-text="${escapeJs(item.password)}">Copy</button>
        <button class="btn btn-small delete-btn" data-id="${id}" style="background: #ff4d4f;">Del</button></div>
    `;
    
    container.appendChild(row);
  });
}

// Fill credentials function
function fillCredentials(username, password) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (username, password) => {
        // Find username/email fields
        const usernameFields = document.querySelectorAll('input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[id*="user"], input[id*="email"]');
        // Find password fields
        const passwordFields = document.querySelectorAll('input[type="password"]');
        
        // Fill username field (first one found)
        if (usernameFields.length > 0 && username) {
          usernameFields[0].value = username;
          usernameFields[0].dispatchEvent(new Event('input', { bubbles: true }));
          usernameFields[0].dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // Fill password field (first one found)
        if (passwordFields.length > 0 && password) {
          passwordFields[0].value = password;
          passwordFields[0].dispatchEvent(new Event('input', { bubbles: true }));
          passwordFields[0].dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // Show feedback
        if (usernameFields.length > 0 || passwordFields.length > 0) {
          const notification = document.createElement('div');
          notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #00fff0;
            color: #000;
            padding: 10px 15px;
            border-radius: 6px;
            font-weight: bold;
            z-index: 10000;
            font-family: sans-serif;
          `;
          notification.textContent = 'Credentials filled!';
          document.body.appendChild(notification);
          
          setTimeout(() => {
            notification.remove();
          }, 2000);
        }
      },
      args: [username, password]
    });
  });
  
  // Close popup after filling
  window.close();
}

// Search functionality
function setupSearch() {
  document.getElementById('searchBox').addEventListener('input', function() {
    const filter = this.value.toLowerCase();
    const items = document.querySelectorAll('.credential-item');
    items.forEach(function(item) {
      const text = item.textContent.toLowerCase();
      item.style.display = text.includes(filter) ? '' : 'none';
    });
  });
}

// Ambient lighting
function setupAmbientLighting() {
  const ambientColorPicker = document.getElementById('ambientColorPicker');
  const lightA = document.getElementById('lightA');
  
  // Load saved color
  chrome.storage.local.get(['ambientLightColor'], (result) => {
    const savedColor = result.ambientLightColor || '#00fff0';
    document.documentElement.style.setProperty('--accent1', savedColor);
    ambientColorPicker.value = savedColor;
  });
  
  ambientColorPicker.addEventListener('input', function() {
    const newColor = this.value;
    document.documentElement.style.setProperty('--accent1', newColor);
    chrome.storage.local.set({ ambientLightColor: newColor });
    
    // Also update content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { 
        action: 'updateAmbientColor', 
        color: newColor 
      });
    });
  });
  
  // Simple animation for popup
  let mouseX = 200, mouseY = 250;
  let posX = mouseX, posY = mouseY;
  const ease = 0.1;
  
  document.addEventListener('mousemove', (e) => {
    const rect = document.body.getBoundingClientRect();
    mouseX = e.clientX - rect.left;
    mouseY = e.clientY - rect.top;
  });
  
  function animate() {
    posX += (mouseX - posX) * ease;
    posY += (mouseY - posY) * ease;
    lightA.style.transform = `translate(${posX}px, ${posY}px)`;
    requestAnimationFrame(animate);
  }
  
  animate();
}

// Auto-fill current page
function setupAutoFill() {
  document.getElementById('fillCurrentPage').addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const currentUrl = tabs[0].url;
      const hostname = new URL(currentUrl).hostname;
      
      const vault = await loadVault();
      const entries = Object.values(vault);
      
      // Find matching entry by hostname
      const matchingEntry = entries.find(entry => 
        entry.name.toLowerCase().includes(hostname.toLowerCase()) ||
        hostname.toLowerCase().includes(entry.name.toLowerCase())
      );
      
      if (matchingEntry) {
        fillCredentials(matchingEntry.username, matchingEntry.password);
      } else {
        alert('No matching credentials found for this site');
      }
    });
  });
}

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  renderList();
  setupSearch();
  setupAmbientLighting();
  setupAutoFill();
  
  document.getElementById('add').addEventListener('click', addEntry);
});




// Event delegation for dynamically created buttons
document.addEventListener("click", (event) => {
  if (event.target.classList.contains("fill-btn")) {
    const username = event.target.dataset.username;
    const password = event.target.dataset.password;
    fillCredentials(username, password);
  } else if (event.target.classList.contains("copy-btn")) {
    const textToCopy = event.target.dataset.text;
    copyTextWithButton(textToCopy, event.target);
  } else if (event.target.classList.contains("delete-btn")) {
    const entryId = event.target.dataset.id;
    delEntry(entryId);
  }
});


