// Background script for OfflineManager extension
// Handles communication between popup and content scripts

const STORAGE_KEY = 'om_pw_vault_v1';

// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getCredentialsForSite') {
    handleGetCredentialsForSite(message.hostname, sendResponse);
    return true; // Keep message channel open for async response
  } else if (message.action === 'openPopup') {
    chrome.action.openPopup();
  } else if (message.action === 'saveCredentials') {
    handleSaveCredentials(message.hostname, message.username, message.password, sendResponse);
    return true; // Keep message channel open for async response
  } else if (message.action === 'addToNeverSave') {
    handleAddToNeverSave(message.hostname, sendResponse);
    return true; // Keep message channel open for async response
  } else if (message.action === 'checkNeverSaveList') {
    handleCheckNeverSaveList(message.hostname, sendResponse);
    return true; // Keep message channel open for async response
  }
});

// Handle saving new credentials
async function handleSaveCredentials(hostname, username, password, sendResponse) {
  try {
    // Get current vault
    const result = await chrome.storage.local.get([STORAGE_KEY]);
    const vault = result[STORAGE_KEY] || {};
    
    // Generate a unique ID for this entry
    const entryId = 'entry_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    
    // Create new entry
    const newEntry = {
      id: entryId,
      name: hostname,
      username: username || '',
      password: password,
      url: `https://${hostname}`,
      created: new Date().toISOString(),
      lastUsed: new Date().toISOString()
    };
    
    // Add to vault
    vault[entryId] = newEntry;
    
    // Save back to storage
    await chrome.storage.local.set({ [STORAGE_KEY]: vault });
    
    sendResponse({ success: true, entryId: entryId });
  } catch (error) {
    console.error('Error saving credentials:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle adding site to never save list
async function handleAddToNeverSave(hostname, sendResponse) {
  try {
    const NEVER_SAVE_KEY = 'om_never_save_sites';
    
    // Get current never save list
    const result = await chrome.storage.local.get([NEVER_SAVE_KEY]);
    const neverSaveList = result[NEVER_SAVE_KEY] || [];
    
    // Add hostname if not already in list
    if (!neverSaveList.includes(hostname)) {
      neverSaveList.push(hostname);
      await chrome.storage.local.set({ [NEVER_SAVE_KEY]: neverSaveList });
    }
    
    sendResponse({ success: true });
  } catch (error) {
    console.error('Error adding to never save list:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// Handle checking if site is in never save list
async function handleCheckNeverSaveList(hostname, sendResponse) {
  try {
    const NEVER_SAVE_KEY = 'om_never_save_sites';
    
    // Get current never save list
    const result = await chrome.storage.local.get([NEVER_SAVE_KEY]);
    const neverSaveList = result[NEVER_SAVE_KEY] || [];
    
    const isInNeverSaveList = neverSaveList.includes(hostname);
    
    sendResponse({ isInNeverSaveList: isInNeverSaveList });
  } catch (error) {
    console.error('Error checking never save list:', error);
    sendResponse({ isInNeverSaveList: false });
  }
}

// Handle getting credentials for a specific site
async function handleGetCredentialsForSite(hostname, sendResponse) {
  try {
    // Get vault from storage
    const result = await chrome.storage.local.get([STORAGE_KEY]);
    const vault = result[STORAGE_KEY] || {};
    
    // Find matching credentials
    const entries = Object.values(vault);
    const matchingEntry = entries.find(entry => {
      const entryName = entry.name.toLowerCase();
      const host = hostname.toLowerCase();
      
      // Check if hostname contains entry name or vice versa
      return entryName.includes(host) || host.includes(entryName) ||
             // Also check for partial matches
             entryName.split('.').some(part => host.includes(part)) ||
             host.split('.').some(part => entryName.includes(part));
    });
    
    if (matchingEntry) {
      sendResponse({
        credentials: {
          username: matchingEntry.username,
          password: matchingEntry.password
        }
      });
    } else {
      sendResponse({ credentials: null });
    }
  } catch (error) {
    console.error('Error getting credentials:', error);
    sendResponse({ credentials: null });
  }
}

// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Show welcome notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon48.png',
      title: 'OfflineManager Installed',
      message: 'Your password vault is ready! Click the extension icon to get started.'
    });
  }
});

// Handle tab updates to detect login pages
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    // Check if this looks like a login page
    const url = tab.url.toLowerCase();
    const loginIndicators = ['login', 'signin', 'auth', 'account', 'user'];
    
    if (loginIndicators.some(indicator => url.includes(indicator))) {
      // Inject content script if not already injected
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
      }).catch(() => {
        // Script might already be injected, ignore error
      });
    }
  }
});

