// Content script for OfflineManager extension
// Handles password field detection and autofill functionality

class OfflineManagerAutofill {
  constructor() {
    this.isEnabled = true;
    this.passwordFields = [];
    this.usernameFields = [];
    this.ambientLayer = null;
    this.init();
  }

  init() {
    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.action === 'updateAmbientColor') {
        this.updateAmbientColor(message.color);
      } else if (message.action === 'fillCredentials') {
        this.fillCredentials(message.username, message.password);
      }
    });

    // Initialize ambient lighting
    this.initAmbientLighting();

    // Detect password fields on page load
    this.detectPasswordFields();
    
    // Watch for dynamically added fields
    this.observeDOM();
    
    // Show autofill suggestions when password fields are focused
    this.setupFieldListeners();
    
    // Monitor for password entry to offer saving
    this.setupPasswordSaveDetection();
  }

  detectPasswordFields() {
    // Find password fields
    this.passwordFields = Array.from(document.querySelectorAll('input[type="password"]'));
    
    // Find potential username fields
    this.usernameFields = Array.from(document.querySelectorAll(`
      input[type="text"],
      input[type="email"],
      input[name*="user" i],
      input[name*="email" i],
      input[name*="login" i],
      input[id*="user" i],
      input[id*="email" i],
      input[id*="login" i],
      input[placeholder*="user" i],
      input[placeholder*="email" i],
      input[placeholder*="login" i]
    `)).filter(field => {
      // Exclude fields that are clearly not username fields
      const excludePatterns = /search|captcha|phone|address|city|zip|postal/i;
      return !excludePatterns.test(field.name + field.id + field.placeholder + field.className);
    });

    // If we found password fields, check if site is recognized
    if (this.passwordFields.length > 0) {
      this.checkSiteRecognitionAndShowNotification();
    }
  }

  observeDOM() {
    const observer = new MutationObserver((mutations) => {
      let shouldRedetect = false;
      
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (node.matches('input[type="password"]') || 
                node.querySelector('input[type="password"]')) {
              shouldRedetect = true;
            }
          }
        });
      });
      
      if (shouldRedetect) {
        setTimeout(() => this.detectPasswordFields(), 100);
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  setupPasswordSaveDetection() {
    // Monitor form submissions and password field changes
    document.addEventListener('submit', (e) => {
      this.handleFormSubmission(e);
    });

    // Also monitor for Enter key in password fields
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.matches('input[type="password"]')) {
        setTimeout(() => {
          this.checkForPasswordSave();
        }, 100);
      }
    });

    // Monitor for navigation away from page (password might have been entered)
    window.addEventListener('beforeunload', () => {
      this.checkForPasswordSave();
    });
  }

  handleFormSubmission(event) {
    const form = event.target;
    
    // Check if form contains password fields
    const passwordField = form.querySelector('input[type="password"]');
    if (!passwordField || !passwordField.value) return;

    // Get username field value
    const usernameField = this.findUsernameFieldInForm(form);
    const username = usernameField ? usernameField.value : '';

    if (username || passwordField.value) {
      // Delay to allow form submission to complete
      setTimeout(() => {
        this.offerToSavePassword(username, passwordField.value);
      }, 500);
    }
  }

  findUsernameFieldInForm(form) {
    // Look for username fields within the form
    const potentialFields = form.querySelectorAll(`
      input[type="text"],
      input[type="email"],
      input[name*="user" i],
      input[name*="email" i],
      input[name*="login" i],
      input[id*="user" i],
      input[id*="email" i],
      input[id*="login" i]
    `);

    // Return the first field that looks like a username field
    for (const field of potentialFields) {
      if (field.value && field.value.trim()) {
        return field;
      }
    }

    return null;
  }

  checkForPasswordSave() {
    // Check if any password fields have values
    const filledPasswordFields = this.passwordFields.filter(field => field.value && field.value.trim());
    if (filledPasswordFields.length === 0) return;

    // Get username from any filled username field
    const filledUsernameField = this.usernameFields.find(field => field.value && field.value.trim());
    const username = filledUsernameField ? filledUsernameField.value : '';

    if (username || filledPasswordFields[0].value) {
      this.offerToSavePassword(username, filledPasswordFields[0].value);
    }
  }

  offerToSavePassword(username, password) {
    // Don't offer if already shown recently
    if (document.querySelector('.om-save-password-prompt')) return;

    const hostname = window.location.hostname;
    
    // Check if this site is in the never save list
    chrome.runtime.sendMessage({
      action: 'checkNeverSaveList',
      hostname: hostname
    }, (neverSaveResponse) => {
      if (neverSaveResponse && neverSaveResponse.isInNeverSaveList) {
        // Site is in never save list, don't prompt
        return;
      }

      // Check if this site already has saved credentials
      chrome.runtime.sendMessage({
        action: 'getCredentialsForSite',
        hostname: hostname
      }, (response) => {
        if (response && response.credentials) {
          // Site already has saved credentials, don't prompt
          return;
        }

        // Show save password prompt
        this.showSavePasswordPrompt(username, password, hostname);
      });
    });
  }

  showSavePasswordPrompt(username, password, hostname) {
    const prompt = document.createElement('div');
    prompt.className = 'om-save-password-prompt';
    prompt.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 8px;">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span>🔐</span>
          <span>Save password for ${hostname}?</span>
        </div>
        <div style="display: flex; gap: 8px;">
          <button class="om-save-btn" style="background: #00fff0; color: #000; border: none; padding: 6px 12px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 12px;">Save</button>
          <button class="om-never-btn" style="background: #666; color: #fff; border: none; padding: 6px 12px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 12px;">Never</button>
          <button class="om-not-now-btn" style="background: transparent; color: #fff; border: 1px solid #666; padding: 6px 12px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 12px;">Not Now</button>
        </div>
      </div>
    `;
    
    prompt.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.95);
      color: white;
      padding: 16px;
      border-radius: 8px;
      font-family: sans-serif;
      font-size: 14px;
      z-index: 10001;
      box-shadow: 0 4px 16px rgba(0,0,0,0.4);
      border: 1px solid #00fff0;
      min-width: 280px;
    `;

    // Save button
    prompt.querySelector('.om-save-btn').addEventListener('click', () => {
      this.savePasswordToVault(username, password, hostname);
      prompt.remove();
    });

    // Never button
    prompt.querySelector('.om-never-btn').addEventListener('click', () => {
      this.addToNeverSaveList(hostname);
      prompt.remove();
    });

    // Not now button
    prompt.querySelector('.om-not-now-btn').addEventListener('click', () => {
      prompt.remove();
    });

    document.body.appendChild(prompt);

    // Auto-remove after 15 seconds
    setTimeout(() => {
      if (prompt.parentNode) {
        prompt.remove();
      }
    }, 15000);
  }

  savePasswordToVault(username, password, hostname) {
    // Send message to background script to save credentials
    chrome.runtime.sendMessage({
      action: 'saveCredentials',
      hostname: hostname,
      username: username,
      password: password
    }, (response) => {
      if (response && response.success) {
        this.showSaveConfirmation();
      }
    });
  }

  addToNeverSaveList(hostname) {
    // Send message to background script to add to never save list
    chrome.runtime.sendMessage({
      action: 'addToNeverSave',
      hostname: hostname
    });
  }

  showSaveConfirmation() {
    const confirmation = document.createElement('div');
    confirmation.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #00fff0;
      color: #000;
      padding: 10px 15px;
      border-radius: 6px;
      font-weight: bold;
      z-index: 10000;
      font-family: sans-serif;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;
    confirmation.textContent = '✓ Password saved!';
    document.body.appendChild(confirmation);

    setTimeout(() => {
      confirmation.remove();
    }, 3000);
  }

  setupFieldListeners() {
    document.addEventListener('focusin', (e) => {
      if (e.target.matches('input[type="password"]') || 
          this.usernameFields.includes(e.target)) {
        this.showQuickFillButton(e.target);
      }
    });

    document.addEventListener('focusout', (e) => {
      // Remove quick fill button after a delay
      setTimeout(() => {
        const existingButton = document.querySelector('.om-quick-fill-btn');
        if (existingButton && !document.activeElement.matches('input[type="password"]') && 
            !this.usernameFields.includes(document.activeElement)) {
          existingButton.remove();
        }
      }, 200);
    });
  }

  checkSiteRecognitionAndShowNotification() {
    // Get current hostname for matching
    const hostname = window.location.hostname;
    
    // Check if site is recognized by sending message to background script
    chrome.runtime.sendMessage({
      action: 'getCredentialsForSite',
      hostname: hostname
    }, (response) => {
      if (response && response.credentials) {
        // Site is recognized - show full notification
        this.showAutofillNotification(true);
      } else {
        // Site is not recognized - show minimal notification
        this.showAutofillNotification(false);
      }
    });
  }

  showQuickFillButton(field) {
    // Remove existing button
    const existing = document.querySelector('.om-quick-fill-btn');
    if (existing) existing.remove();

    // Create quick fill button
    const button = document.createElement('button');
    button.className = 'om-quick-fill-btn';
    button.innerHTML = '🔑 Fill';
    button.style.cssText = `
      position: absolute;
      background: #00fff0;
      color: #000;
      border: none;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: bold;
      cursor: pointer;
      z-index: 10000;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      font-family: sans-serif;
    `;

    // Position button near the field
    const rect = field.getBoundingClientRect();
    button.style.left = (rect.right + window.scrollX - 50) + 'px';
    button.style.top = (rect.top + window.scrollY - 30) + 'px';

    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      this.requestAutofill();
      button.remove();
    });

    document.body.appendChild(button);
  }

  showAutofillNotification(isRecognizedSite = false) {
    // Don't show if already shown recently
    if (document.querySelector('.om-autofill-notification')) return;

    const notification = document.createElement('div');
    notification.className = 'om-autofill-notification';
    
    if (isRecognizedSite) {
      // Full notification for recognized sites
      notification.innerHTML = `
        <div style="display: flex; align-items: center; gap: 8px;">
          <span>🔑</span>
          <span>OfflineManager can autofill this form</span>
          <button class="om-fill-btn" style="background: #00fff0; color: #000; border: none; padding: 4px 8px; border-radius: 4px; font-weight: bold; cursor: pointer;">Fill</button>
          <button class="om-close-btn" style="background: transparent; color: #fff; border: none; cursor: pointer; font-size: 16px;">×</button>
        </div>
      `;
      
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 12px 16px;
        border-radius: 8px;
        font-family: sans-serif;
        font-size: 14px;
        z-index: 10000;
        box-shadow: 0 4px 16px rgba(0,0,0,0.3);
        border: 1px solid #00fff0;
      `;
    } else {
      // Minimal notification for unrecognized sites
      notification.innerHTML = `
        <button class="om-fill-btn" style="background: #00fff0; color: #000; border: none; padding: 6px 10px; border-radius: 4px; font-weight: bold; cursor: pointer; font-size: 12px;">🔑 Fill</button>
      `;
      
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        font-family: sans-serif;
      `;
    }

    notification.querySelector('.om-fill-btn').addEventListener('click', () => {
      this.requestAutofill();
      notification.remove();
    });

    const closeBtn = notification.querySelector('.om-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        notification.remove();
      });
    }

    document.body.appendChild(notification);

    // Auto-remove after different times based on recognition
    const autoRemoveTime = isRecognizedSite ? 10000 : 5000;
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, autoRemoveTime);
  }

  requestAutofill() {
    // Get current hostname for matching
    const hostname = window.location.hostname;
    
    // Send message to background script to get matching credentials
    chrome.runtime.sendMessage({
      action: 'getCredentialsForSite',
      hostname: hostname
    }, (response) => {
      if (response && response.credentials) {
        this.fillCredentials(response.credentials.username, response.credentials.password);
      } else {
        // Show popup for manual selection
        chrome.runtime.sendMessage({ action: 'openPopup' });
      }
    });
  }

  fillCredentials(username, password) {
    let filled = false;

    // Fill username field
    if (username && this.usernameFields.length > 0) {
      const usernameField = this.usernameFields[0];
      this.fillField(usernameField, username);
      filled = true;
    }

    // Fill password field
    if (password && this.passwordFields.length > 0) {
      const passwordField = this.passwordFields[0];
      this.fillField(passwordField, password);
      filled = true;
    }

    if (filled) {
      this.showFillConfirmation();
    }
  }

  fillField(field, value) {
    // Set value
    field.value = value;
    
    // Trigger events to notify the page
    field.dispatchEvent(new Event('input', { bubbles: true }));
    field.dispatchEvent(new Event('change', { bubbles: true }));
    field.dispatchEvent(new Event('keyup', { bubbles: true }));
    
    // Focus briefly to ensure the field is recognized as filled
    field.focus();
    field.blur();
  }

  showFillConfirmation() {
    const confirmation = document.createElement('div');
    confirmation.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: #00fff0;
      color: #000;
      padding: 10px 15px;
      border-radius: 6px;
      font-weight: bold;
      z-index: 10000;
      font-family: sans-serif;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    `;
    confirmation.textContent = '✓ Credentials filled!';
    document.body.appendChild(confirmation);

    setTimeout(() => {
      confirmation.remove();
    }, 2000);
  }

  updateAmbientColor(color) {
    // Update CSS custom property
    document.documentElement.style.setProperty('--om-ambient-color', color);
    
    // Save to storage for persistence
    chrome.storage.local.set({ ambientLightColor: color });
  }

  initAmbientLighting() {
    // Load saved ambient color
    chrome.storage.local.get(['ambientLightColor'], (result) => {
      const savedColor = result.ambientLightColor || '#00fff0';
      document.documentElement.style.setProperty('--om-ambient-color', savedColor);
    });

    // Create ambient lighting layer
    this.createAmbientLayer();
  }

  createAmbientLayer() {
    // Don't create if already exists
    if (document.querySelector('.om-ambient-layer')) return;

    // Create ambient layer
    this.ambientLayer = document.createElement('div');
    this.ambientLayer.className = 'om-ambient-layer';
    
    // Create multiple light orbs
    for (let i = 1; i <= 3; i++) {
      const light = document.createElement('div');
      light.className = `om-ambient-light light-${i}`;
      this.ambientLayer.appendChild(light);
    }

    // Add to page
    document.body.appendChild(this.ambientLayer);

    // Add mouse interaction to first light
    this.setupMouseInteraction();
  }

  setupMouseInteraction() {
    const primaryLight = this.ambientLayer.querySelector('.light-1');
    if (!primaryLight) return;

    let mouseX = window.innerWidth * 0.8;
    let mouseY = window.innerHeight * 0.2;
    let targetX = mouseX;
    let targetY = mouseY;

    // Follow mouse with smooth easing
    document.addEventListener('mousemove', (e) => {
      targetX = e.clientX;
      targetY = e.clientY;
    });

    const animate = () => {
      mouseX += (targetX - mouseX) * 0.05;
      mouseY += (targetY - mouseY) * 0.05;

      primaryLight.style.left = (mouseX / window.innerWidth * 100) + '%';
      primaryLight.style.top = (mouseY / window.innerHeight * 100) + '%';

      requestAnimationFrame(animate);
    };

    animate();
  }
}

// Initialize the autofill system
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    new OfflineManagerAutofill();
  });
} else {
  new OfflineManagerAutofill();
}

