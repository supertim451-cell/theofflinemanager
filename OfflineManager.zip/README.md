# OfflineManager Browser Extension

A secure, local password vault with autofill functionality and customizable ambient lighting effects.

## Features

- **Local Password Storage**: All passwords are stored locally in your browser - no cloud sync, no external servers
- **Smart Autofill**: Automatically detects login forms and offers to fill credentials
- **Ambient Lighting**: Customizable aqua ambient lighting effects on web pages
- **Search & Filter**: Quickly find stored credentials with built-in search
- **Secure**: Uses browser's built-in storage encryption

## Installation

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable "Developer mode" in the top right
3. Click "Load unpacked" and select the extension folder
4. The OfflineManager icon should appear in your toolbar

## Usage

### Adding Passwords
1. Click the OfflineManager extension icon
2. Fill in the site name, username, and password
3. Click "Add Entry"

### Auto-filling Passwords
1. Visit a login page
2. Click the extension icon and select "Fill Current Page"
3. Or use the "Fill" button next to specific credentials

### Customizing Ambient Lighting
1. Open the extension popup
2. Use the color picker in the Settings section
3. The ambient lighting color will update across all websites

## Security

- All data is stored locally using Chrome's secure storage API
- No data is transmitted to external servers
- Passwords are only accessible within your browser profile

## Files Structure

- `manifest.json` - Extension configuration
- `popup.html/js` - Main interface
- `content.js` - Page interaction and autofill logic
- `background.js` - Extension coordination
- `ambient.css` - Ambient lighting styles
- `icons/` - Extension icons

## Permissions

- `storage` - For saving passwords locally
- `activeTab` - For autofill functionality
- `scripting` - For injecting autofill scripts
- `<all_urls>` - For ambient lighting on all websites

